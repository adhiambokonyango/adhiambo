-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 20, 2020 at 01:59 PM
-- Server version: 5.7.29
-- PHP Version: 7.1.33-14+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reunion`
--

-- --------------------------------------------------------

--
-- Table structure for table `actual_deductions`
--

CREATE TABLE `actual_deductions` (
  `ActualDeductionId` int(11) NOT NULL,
  `DeductionTypeId` int(11) NOT NULL,
  `ActualQuarterId` int(11) NOT NULL,
  `MonthsId` int(11) NOT NULL,
  `DeductionAmount` int(11) NOT NULL,
  `DeductionDescription` varchar(200) NOT NULL,
  `DeductionDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `actual_quarter`
--

CREATE TABLE `actual_quarter` (
  `ActualQuarterId` int(11) NOT NULL,
  `QuarterIterationId` int(11) NOT NULL,
  `YearId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `AddressId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `CountyId` int(11) NOT NULL,
  `SubCountyId` int(11) NOT NULL,
  `EstateDescription` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cash_flow`
--

CREATE TABLE `cash_flow` (
  `CashFlowId` int(11) NOT NULL,
  `CashFlowTypeId` int(11) NOT NULL,
  `ContributionId` int(11) NOT NULL,
  `ActualDeductionId` int(11) NOT NULL,
  `PreviousOrganizationAmount` int(11) NOT NULL,
  `NextOrganizationAmount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cash_flow_types`
--

CREATE TABLE `cash_flow_types` (
  `CashFlowTypeId` int(11) NOT NULL,
  `CashFLowTypeDescription` varchar(200) NOT NULL,
  `CashFLowCode` int(11) NOT NULL,
  `FlowFlag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `children`
--

CREATE TABLE `children` (
  `ChildrenId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `children_cousins`
--

CREATE TABLE `children_cousins` (
  `ChildrenCousinId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `ContactDetailsId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `PhoneNumber` varchar(200) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `AlternativePhoneNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contribution_report_update`
--

CREATE TABLE `contribution_report_update` (
  `UpdateId` int(11) NOT NULL,
  `ContributionReportId` int(11) NOT NULL,
  `ContributionId` int(11) NOT NULL,
  `PreviousContributionAmount` int(11) NOT NULL,
  `PreviousMonthBalance` int(11) NOT NULL,
  `PreviousAnnualBalance` int(11) NOT NULL,
  `NextContributionAmount` int(11) NOT NULL,
  `NextMonthBalance` int(11) NOT NULL,
  `NextAnnualBalance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cousins`
--

CREATE TABLE `cousins` (
  `CousinsId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `deduction_type`
--

CREATE TABLE `deduction_type` (
  `DeductionTypeId` int(11) NOT NULL,
  `DeductionTypeDescription` int(11) NOT NULL,
  `DeductionTypeCode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gender`
--

CREATE TABLE `gender` (
  `GenderId` int(11) NOT NULL,
  `GenderDescription` varchar(200) NOT NULL,
  `GenderCode` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggggr_children`
--

CREATE TABLE `gggggr_children` (
  `GGGGGrCId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggggr_children_cousins`
--

CREATE TABLE `gggggr_children_cousins` (
  `GGGGGrChildrenCousin` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggggr_parents`
--

CREATE TABLE `gggggr_parents` (
  `GGGGGrPId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggggr_parents_cousins`
--

CREATE TABLE `gggggr_parents_cousins` (
  `GGGGGrPCousinId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggggr_parents_siblings`
--

CREATE TABLE `gggggr_parents_siblings` (
  `GGGGGrPSId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggggr_children`
--

CREATE TABLE `ggggr_children` (
  `GGGGrCId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggggr_children_cousins`
--

CREATE TABLE `ggggr_children_cousins` (
  `GGGGrChildrenCousin` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggggr_parents`
--

CREATE TABLE `ggggr_parents` (
  `GGGGrPId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggggr_parents_cousins`
--

CREATE TABLE `ggggr_parents_cousins` (
  `GGGGrPCousinId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggggr_parents_siblings`
--

CREATE TABLE `ggggr_parents_siblings` (
  `GGGGrPSId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggr_children`
--

CREATE TABLE `gggr_children` (
  `GGGrCId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggr_children_cousins`
--

CREATE TABLE `gggr_children_cousins` (
  `GGGrChildrenCousinId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggr_parents`
--

CREATE TABLE `gggr_parents` (
  `GGGrPId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggr_parents_cousins`
--

CREATE TABLE `gggr_parents_cousins` (
  `GGGrPCousinsId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gggr_parents_siblings`
--

CREATE TABLE `gggr_parents_siblings` (
  `GGGrPSId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggr_children`
--

CREATE TABLE `ggr_children` (
  `GGrCId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggr_children_cousin`
--

CREATE TABLE `ggr_children_cousin` (
  `GGrChildrenCousinId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggr_parents`
--

CREATE TABLE `ggr_parents` (
  `GGrPId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggr_parents_cousins`
--

CREATE TABLE `ggr_parents_cousins` (
  `GGrPCousins` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ggr_parents_siblings`
--

CREATE TABLE `ggr_parents_siblings` (
  `GGrPSId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gr_children`
--

CREATE TABLE `gr_children` (
  `GrCId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gr_children_cousins`
--

CREATE TABLE `gr_children_cousins` (
  `GrChildrenCousinId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gr_parents`
--

CREATE TABLE `gr_parents` (
  `GrPId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gr_parents_cousins`
--

CREATE TABLE `gr_parents_cousins` (
  `GrPCousins` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gr_parents_siblings`
--

CREATE TABLE `gr_parents_siblings` (
  `GrPSId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `months`
--

CREATE TABLE `months` (
  `MonthsId` int(11) NOT NULL,
  `MonthsIterationId` int(11) NOT NULL,
  `QuarterIterationId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `months_iterations`
--

CREATE TABLE `months_iterations` (
  `MonthsIterationId` int(11) NOT NULL,
  `MonthsIterationDescription` int(11) NOT NULL,
  `MonthsIterationCode` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `organizational_overall_amount`
--

CREATE TABLE `organizational_overall_amount` (
  `OrganizationalOverallAmountId` int(11) NOT NULL,
  `OrganizationalOverallAmount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parents`
--

CREATE TABLE `parents` (
  `ParentId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parents_siblings`
--

CREATE TABLE `parents_siblings` (
  `ParentsSiblingsId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parent_cousins`
--

CREATE TABLE `parent_cousins` (
  `ParentCousinsId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `quarter_iteration`
--

CREATE TABLE `quarter_iteration` (
  `QuarterIterationId` int(11) NOT NULL,
  `IterationDescription` varchar(200) NOT NULL,
  `IterationCode` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `siblings`
--

CREATE TABLE `siblings` (
  `SiblingId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Spouse`
--

CREATE TABLE `Spouse` (
  `SpouseId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `RelativeId` int(11) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserId` int(11) NOT NULL,
  `FirstName` varchar(200) NOT NULL,
  `MiddleName` varchar(200) NOT NULL,
  `SurName` varchar(200) NOT NULL,
  `GenderId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_contributions`
--

CREATE TABLE `user_contributions` (
  `ContributionId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `MonthsId` int(11) NOT NULL,
  `ActualQuarterId` int(11) NOT NULL,
  `ContributionAmount` int(11) NOT NULL,
  `SessionId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_contribution_report`
--

CREATE TABLE `user_contribution_report` (
  `ContributionReportId` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `MonthsId` int(11) NOT NULL,
  `ExpectedAmount` int(11) NOT NULL,
  `ContributedAmount` int(11) NOT NULL,
  `MonthBalance` int(11) NOT NULL,
  `AnnualBalance` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `years`
--

CREATE TABLE `years` (
  `YearId` int(11) NOT NULL,
  `Year` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actual_deductions`
--
ALTER TABLE `actual_deductions`
  ADD PRIMARY KEY (`ActualDeductionId`),
  ADD KEY `DeductionTypeId` (`DeductionTypeId`),
  ADD KEY `ActualQuarterId` (`ActualQuarterId`),
  ADD KEY `MonthsId` (`MonthsId`);

--
-- Indexes for table `actual_quarter`
--
ALTER TABLE `actual_quarter`
  ADD PRIMARY KEY (`ActualQuarterId`),
  ADD KEY `YearId` (`YearId`),
  ADD KEY `QuarterIterationId` (`QuarterIterationId`);

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`AddressId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `cash_flow`
--
ALTER TABLE `cash_flow`
  ADD PRIMARY KEY (`CashFlowId`),
  ADD KEY `CashFlowTypeId` (`CashFlowTypeId`),
  ADD KEY `ContributionId` (`ContributionId`),
  ADD KEY `ActualDeductionId` (`ActualDeductionId`);

--
-- Indexes for table `cash_flow_types`
--
ALTER TABLE `cash_flow_types`
  ADD PRIMARY KEY (`CashFlowTypeId`);

--
-- Indexes for table `children`
--
ALTER TABLE `children`
  ADD PRIMARY KEY (`ChildrenId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `children_cousins`
--
ALTER TABLE `children_cousins`
  ADD PRIMARY KEY (`ChildrenCousinId`),
  ADD KEY `GenderId` (`GenderId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`ContactDetailsId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `contribution_report_update`
--
ALTER TABLE `contribution_report_update`
  ADD PRIMARY KEY (`UpdateId`),
  ADD KEY `ContributionReportId` (`ContributionReportId`),
  ADD KEY `ContributionId` (`ContributionId`);

--
-- Indexes for table `cousins`
--
ALTER TABLE `cousins`
  ADD PRIMARY KEY (`CousinsId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `deduction_type`
--
ALTER TABLE `deduction_type`
  ADD PRIMARY KEY (`DeductionTypeId`);

--
-- Indexes for table `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`GenderId`);

--
-- Indexes for table `gggggr_children`
--
ALTER TABLE `gggggr_children`
  ADD PRIMARY KEY (`GGGGGrCId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gggggr_children_cousins`
--
ALTER TABLE `gggggr_children_cousins`
  ADD PRIMARY KEY (`GGGGGrChildrenCousin`),
  ADD KEY `GenderId` (`GenderId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `gggggr_parents`
--
ALTER TABLE `gggggr_parents`
  ADD PRIMARY KEY (`GGGGGrPId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gggggr_parents_cousins`
--
ALTER TABLE `gggggr_parents_cousins`
  ADD PRIMARY KEY (`GGGGGrPCousinId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gggggr_parents_siblings`
--
ALTER TABLE `gggggr_parents_siblings`
  ADD PRIMARY KEY (`GGGGGrPSId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `ggggr_children`
--
ALTER TABLE `ggggr_children`
  ADD PRIMARY KEY (`GGGGrCId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `ggggr_children_cousins`
--
ALTER TABLE `ggggr_children_cousins`
  ADD PRIMARY KEY (`GGGGrChildrenCousin`),
  ADD KEY `GenderId` (`GenderId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `ggggr_parents`
--
ALTER TABLE `ggggr_parents`
  ADD PRIMARY KEY (`GGGGrPId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `ggggr_parents_cousins`
--
ALTER TABLE `ggggr_parents_cousins`
  ADD PRIMARY KEY (`GGGGrPCousinId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `ggggr_parents_siblings`
--
ALTER TABLE `ggggr_parents_siblings`
  ADD PRIMARY KEY (`GGGGrPSId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gggr_children`
--
ALTER TABLE `gggr_children`
  ADD PRIMARY KEY (`GGGrCId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gggr_children_cousins`
--
ALTER TABLE `gggr_children_cousins`
  ADD PRIMARY KEY (`GGGrChildrenCousinId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gggr_parents`
--
ALTER TABLE `gggr_parents`
  ADD PRIMARY KEY (`GGGrPId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gggr_parents_cousins`
--
ALTER TABLE `gggr_parents_cousins`
  ADD PRIMARY KEY (`GGGrPCousinsId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `gggr_parents_siblings`
--
ALTER TABLE `gggr_parents_siblings`
  ADD PRIMARY KEY (`GGGrPSId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `ggr_children`
--
ALTER TABLE `ggr_children`
  ADD PRIMARY KEY (`GGrCId`),
  ADD KEY `GenderId` (`GenderId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `ggr_children_cousin`
--
ALTER TABLE `ggr_children_cousin`
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `ggr_parents`
--
ALTER TABLE `ggr_parents`
  ADD PRIMARY KEY (`GGrPId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `ggr_parents_cousins`
--
ALTER TABLE `ggr_parents_cousins`
  ADD PRIMARY KEY (`GGrPCousins`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `ggr_parents_siblings`
--
ALTER TABLE `ggr_parents_siblings`
  ADD PRIMARY KEY (`GGrPSId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gr_children`
--
ALTER TABLE `gr_children`
  ADD PRIMARY KEY (`GrCId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gr_children_cousins`
--
ALTER TABLE `gr_children_cousins`
  ADD PRIMARY KEY (`GrChildrenCousinId`),
  ADD KEY `GenderId` (`GenderId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `gr_parents`
--
ALTER TABLE `gr_parents`
  ADD PRIMARY KEY (`GrPId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gr_parents_cousins`
--
ALTER TABLE `gr_parents_cousins`
  ADD PRIMARY KEY (`GrPCousins`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `gr_parents_siblings`
--
ALTER TABLE `gr_parents_siblings`
  ADD PRIMARY KEY (`GrPSId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `months`
--
ALTER TABLE `months`
  ADD PRIMARY KEY (`MonthsId`),
  ADD KEY `QuarterIterationId` (`QuarterIterationId`),
  ADD KEY `MonthsIterationId` (`MonthsIterationId`);

--
-- Indexes for table `months_iterations`
--
ALTER TABLE `months_iterations`
  ADD PRIMARY KEY (`MonthsIterationId`);

--
-- Indexes for table `organizational_overall_amount`
--
ALTER TABLE `organizational_overall_amount`
  ADD PRIMARY KEY (`OrganizationalOverallAmountId`);

--
-- Indexes for table `parents`
--
ALTER TABLE `parents`
  ADD PRIMARY KEY (`ParentId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `parents_siblings`
--
ALTER TABLE `parents_siblings`
  ADD PRIMARY KEY (`ParentsSiblingsId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `parent_cousins`
--
ALTER TABLE `parent_cousins`
  ADD PRIMARY KEY (`ParentCousinsId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `quarter_iteration`
--
ALTER TABLE `quarter_iteration`
  ADD PRIMARY KEY (`QuarterIterationId`);

--
-- Indexes for table `siblings`
--
ALTER TABLE `siblings`
  ADD PRIMARY KEY (`SiblingId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `Spouse`
--
ALTER TABLE `Spouse`
  ADD PRIMARY KEY (`SpouseId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`UserId`),
  ADD KEY `GenderId` (`GenderId`);

--
-- Indexes for table `user_contributions`
--
ALTER TABLE `user_contributions`
  ADD PRIMARY KEY (`ContributionId`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `MonthsId` (`MonthsId`),
  ADD KEY `ActualQuarterId` (`ActualQuarterId`);

--
-- Indexes for table `user_contribution_report`
--
ALTER TABLE `user_contribution_report`
  ADD PRIMARY KEY (`ContributionReportId`),
  ADD KEY `MonthsId` (`MonthsId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `years`
--
ALTER TABLE `years`
  ADD PRIMARY KEY (`YearId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actual_deductions`
--
ALTER TABLE `actual_deductions`
  MODIFY `ActualDeductionId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `actual_quarter`
--
ALTER TABLE `actual_quarter`
  MODIFY `ActualQuarterId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `AddressId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cash_flow`
--
ALTER TABLE `cash_flow`
  MODIFY `CashFlowId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cash_flow_types`
--
ALTER TABLE `cash_flow_types`
  MODIFY `CashFlowTypeId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `children`
--
ALTER TABLE `children`
  MODIFY `ChildrenId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `children_cousins`
--
ALTER TABLE `children_cousins`
  MODIFY `ChildrenCousinId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `ContactDetailsId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contribution_report_update`
--
ALTER TABLE `contribution_report_update`
  MODIFY `UpdateId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cousins`
--
ALTER TABLE `cousins`
  MODIFY `CousinsId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `deduction_type`
--
ALTER TABLE `deduction_type`
  MODIFY `DeductionTypeId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gender`
--
ALTER TABLE `gender`
  MODIFY `GenderId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggggr_children`
--
ALTER TABLE `gggggr_children`
  MODIFY `GGGGGrCId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggggr_children_cousins`
--
ALTER TABLE `gggggr_children_cousins`
  MODIFY `GGGGGrChildrenCousin` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggggr_parents`
--
ALTER TABLE `gggggr_parents`
  MODIFY `GGGGGrPId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggggr_parents_cousins`
--
ALTER TABLE `gggggr_parents_cousins`
  MODIFY `GGGGGrPCousinId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggggr_parents_siblings`
--
ALTER TABLE `gggggr_parents_siblings`
  MODIFY `GGGGGrPSId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ggggr_children`
--
ALTER TABLE `ggggr_children`
  MODIFY `GGGGrCId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ggggr_children_cousins`
--
ALTER TABLE `ggggr_children_cousins`
  MODIFY `GGGGrChildrenCousin` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ggggr_parents`
--
ALTER TABLE `ggggr_parents`
  MODIFY `GGGGrPId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ggggr_parents_cousins`
--
ALTER TABLE `ggggr_parents_cousins`
  MODIFY `GGGGrPCousinId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ggggr_parents_siblings`
--
ALTER TABLE `ggggr_parents_siblings`
  MODIFY `GGGGrPSId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggr_children`
--
ALTER TABLE `gggr_children`
  MODIFY `GGGrCId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggr_children_cousins`
--
ALTER TABLE `gggr_children_cousins`
  MODIFY `GGGrChildrenCousinId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggr_parents`
--
ALTER TABLE `gggr_parents`
  MODIFY `GGGrPId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggr_parents_cousins`
--
ALTER TABLE `gggr_parents_cousins`
  MODIFY `GGGrPCousinsId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gggr_parents_siblings`
--
ALTER TABLE `gggr_parents_siblings`
  MODIFY `GGGrPSId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ggr_children`
--
ALTER TABLE `ggr_children`
  MODIFY `GGrCId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ggr_parents`
--
ALTER TABLE `ggr_parents`
  MODIFY `GGrPId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ggr_parents_cousins`
--
ALTER TABLE `ggr_parents_cousins`
  MODIFY `GGrPCousins` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ggr_parents_siblings`
--
ALTER TABLE `ggr_parents_siblings`
  MODIFY `GGrPSId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gr_children`
--
ALTER TABLE `gr_children`
  MODIFY `GrCId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gr_children_cousins`
--
ALTER TABLE `gr_children_cousins`
  MODIFY `GrChildrenCousinId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gr_parents`
--
ALTER TABLE `gr_parents`
  MODIFY `GrPId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gr_parents_cousins`
--
ALTER TABLE `gr_parents_cousins`
  MODIFY `GrPCousins` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gr_parents_siblings`
--
ALTER TABLE `gr_parents_siblings`
  MODIFY `GrPSId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `months`
--
ALTER TABLE `months`
  MODIFY `MonthsId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `months_iterations`
--
ALTER TABLE `months_iterations`
  MODIFY `MonthsIterationId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `organizational_overall_amount`
--
ALTER TABLE `organizational_overall_amount`
  MODIFY `OrganizationalOverallAmountId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `parents`
--
ALTER TABLE `parents`
  MODIFY `ParentId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `parents_siblings`
--
ALTER TABLE `parents_siblings`
  MODIFY `ParentsSiblingsId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `parent_cousins`
--
ALTER TABLE `parent_cousins`
  MODIFY `ParentCousinsId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `quarter_iteration`
--
ALTER TABLE `quarter_iteration`
  MODIFY `QuarterIterationId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `siblings`
--
ALTER TABLE `siblings`
  MODIFY `SiblingId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Spouse`
--
ALTER TABLE `Spouse`
  MODIFY `SpouseId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `UserId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_contributions`
--
ALTER TABLE `user_contributions`
  MODIFY `ContributionId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_contribution_report`
--
ALTER TABLE `user_contribution_report`
  MODIFY `ContributionReportId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `years`
--
ALTER TABLE `years`
  MODIFY `YearId` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `actual_deductions`
--
ALTER TABLE `actual_deductions`
  ADD CONSTRAINT `actual_deductions_ibfk_1` FOREIGN KEY (`DeductionTypeId`) REFERENCES `deduction_type` (`DeductionTypeId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `actual_deductions_ibfk_2` FOREIGN KEY (`ActualQuarterId`) REFERENCES `actual_quarter` (`ActualQuarterId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `actual_deductions_ibfk_3` FOREIGN KEY (`MonthsId`) REFERENCES `months` (`MonthsId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `actual_quarter`
--
ALTER TABLE `actual_quarter`
  ADD CONSTRAINT `actual_quarter_ibfk_1` FOREIGN KEY (`YearId`) REFERENCES `years` (`YearId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `actual_quarter_ibfk_2` FOREIGN KEY (`QuarterIterationId`) REFERENCES `quarter_iteration` (`QuarterIterationId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cash_flow`
--
ALTER TABLE `cash_flow`
  ADD CONSTRAINT `cash_flow_ibfk_1` FOREIGN KEY (`CashFlowTypeId`) REFERENCES `cash_flow_types` (`CashFlowTypeId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cash_flow_ibfk_2` FOREIGN KEY (`ContributionId`) REFERENCES `user_contributions` (`ContributionId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cash_flow_ibfk_3` FOREIGN KEY (`ActualDeductionId`) REFERENCES `actual_deductions` (`ActualDeductionId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `children`
--
ALTER TABLE `children`
  ADD CONSTRAINT `children_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `children_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `children_cousins`
--
ALTER TABLE `children_cousins`
  ADD CONSTRAINT `children_cousins_ibfk_1` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `children_cousins_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contribution_report_update`
--
ALTER TABLE `contribution_report_update`
  ADD CONSTRAINT `contribution_report_update_ibfk_1` FOREIGN KEY (`ContributionReportId`) REFERENCES `user_contribution_report` (`ContributionReportId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `contribution_report_update_ibfk_2` FOREIGN KEY (`ContributionId`) REFERENCES `user_contributions` (`ContributionId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cousins`
--
ALTER TABLE `cousins`
  ADD CONSTRAINT `cousins_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cousins_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggggr_children`
--
ALTER TABLE `gggggr_children`
  ADD CONSTRAINT `gggggr_children_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggggr_children_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggggr_children_cousins`
--
ALTER TABLE `gggggr_children_cousins`
  ADD CONSTRAINT `gggggr_children_cousins_ibfk_1` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggggr_children_cousins_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggggr_parents`
--
ALTER TABLE `gggggr_parents`
  ADD CONSTRAINT `gggggr_parents_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggggr_parents_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggggr_parents_cousins`
--
ALTER TABLE `gggggr_parents_cousins`
  ADD CONSTRAINT `gggggr_parents_cousins_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggggr_parents_cousins_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggggr_parents_siblings`
--
ALTER TABLE `gggggr_parents_siblings`
  ADD CONSTRAINT `gggggr_parents_siblings_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggggr_parents_siblings_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggggr_children`
--
ALTER TABLE `ggggr_children`
  ADD CONSTRAINT `ggggr_children_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggggr_children_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggggr_children_cousins`
--
ALTER TABLE `ggggr_children_cousins`
  ADD CONSTRAINT `ggggr_children_cousins_ibfk_1` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggggr_children_cousins_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggggr_parents`
--
ALTER TABLE `ggggr_parents`
  ADD CONSTRAINT `ggggr_parents_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggggr_parents_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggggr_parents_ibfk_3` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggggr_parents_cousins`
--
ALTER TABLE `ggggr_parents_cousins`
  ADD CONSTRAINT `ggggr_parents_cousins_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggggr_parents_cousins_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggggr_parents_siblings`
--
ALTER TABLE `ggggr_parents_siblings`
  ADD CONSTRAINT `ggggr_parents_siblings_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggggr_parents_siblings_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggggr_parents_siblings_ibfk_3` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggr_children`
--
ALTER TABLE `gggr_children`
  ADD CONSTRAINT `gggr_children_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggr_children_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggr_children_cousins`
--
ALTER TABLE `gggr_children_cousins`
  ADD CONSTRAINT `gggr_children_cousins_ibfk_1` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggr_children_cousins_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggr_children_cousins_ibfk_3` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggr_parents`
--
ALTER TABLE `gggr_parents`
  ADD CONSTRAINT `gggr_parents_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggr_parents_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggr_parents_cousins`
--
ALTER TABLE `gggr_parents_cousins`
  ADD CONSTRAINT `gggr_parents_cousins_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gggr_parents_siblings`
--
ALTER TABLE `gggr_parents_siblings`
  ADD CONSTRAINT `gggr_parents_siblings_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gggr_parents_siblings_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggr_children`
--
ALTER TABLE `ggr_children`
  ADD CONSTRAINT `ggr_children_ibfk_1` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggr_children_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggr_children_cousin`
--
ALTER TABLE `ggr_children_cousin`
  ADD CONSTRAINT `ggr_children_cousin_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggr_children_cousin_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggr_parents`
--
ALTER TABLE `ggr_parents`
  ADD CONSTRAINT `ggr_parents_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggr_parents_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggr_parents_ibfk_3` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggr_parents_cousins`
--
ALTER TABLE `ggr_parents_cousins`
  ADD CONSTRAINT `ggr_parents_cousins_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggr_parents_cousins_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ggr_parents_siblings`
--
ALTER TABLE `ggr_parents_siblings`
  ADD CONSTRAINT `ggr_parents_siblings_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `ggr_parents_siblings_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gr_children`
--
ALTER TABLE `gr_children`
  ADD CONSTRAINT `gr_children_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gr_children_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gr_children_cousins`
--
ALTER TABLE `gr_children_cousins`
  ADD CONSTRAINT `gr_children_cousins_ibfk_1` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gr_children_cousins_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gr_children_cousins_ibfk_3` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gr_parents`
--
ALTER TABLE `gr_parents`
  ADD CONSTRAINT `gr_parents_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gr_parents_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gr_parents_cousins`
--
ALTER TABLE `gr_parents_cousins`
  ADD CONSTRAINT `gr_parents_cousins_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gr_parents_cousins_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gr_parents_siblings`
--
ALTER TABLE `gr_parents_siblings`
  ADD CONSTRAINT `gr_parents_siblings_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gr_parents_siblings_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `months`
--
ALTER TABLE `months`
  ADD CONSTRAINT `months_ibfk_1` FOREIGN KEY (`QuarterIterationId`) REFERENCES `quarter_iteration` (`QuarterIterationId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `months_ibfk_2` FOREIGN KEY (`MonthsIterationId`) REFERENCES `months_iterations` (`MonthsIterationId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parents`
--
ALTER TABLE `parents`
  ADD CONSTRAINT `parents_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `parents_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parents_siblings`
--
ALTER TABLE `parents_siblings`
  ADD CONSTRAINT `parents_siblings_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `parents_siblings_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `parent_cousins`
--
ALTER TABLE `parent_cousins`
  ADD CONSTRAINT `parent_cousins_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `parent_cousins_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `siblings`
--
ALTER TABLE `siblings`
  ADD CONSTRAINT `siblings_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `siblings_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Spouse`
--
ALTER TABLE `Spouse`
  ADD CONSTRAINT `Spouse_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `Spouse_ibfk_2` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`GenderId`) REFERENCES `gender` (`GenderId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_contributions`
--
ALTER TABLE `user_contributions`
  ADD CONSTRAINT `user_contributions_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_contributions_ibfk_2` FOREIGN KEY (`MonthsId`) REFERENCES `months` (`MonthsId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_contributions_ibfk_3` FOREIGN KEY (`ActualQuarterId`) REFERENCES `actual_quarter` (`ActualQuarterId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_contribution_report`
--
ALTER TABLE `user_contribution_report`
  ADD CONSTRAINT `user_contribution_report_ibfk_1` FOREIGN KEY (`MonthsId`) REFERENCES `months` (`MonthsId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_contribution_report_ibfk_2` FOREIGN KEY (`UserId`) REFERENCES `users` (`UserId`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
