-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 23, 2020 at 09:32 AM
-- Server version: 5.7.29
-- PHP Version: 7.1.33-14+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taskSchedular`
--

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `CompanyId` int(11) NOT NULL,
  `CompanyName` varchar(200) NOT NULL,
  `CompanyEmail` varchar(200) NOT NULL,
  `CompanyPostalAdress` varchar(200) NOT NULL,
  `CompanyLocation` varchar(200) NOT NULL,
  `CompanyTelephone` int(11) NOT NULL,
  `CompanyMission` varchar(5000) NOT NULL,
  `CompanyVision` varchar(5000) NOT NULL,
  `CompanyAbout` varchar(5000) NOT NULL,
  `CompanyVacancy` varchar(9000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`CompanyId`, `CompanyName`, `CompanyEmail`, `CompanyPostalAdress`, `CompanyLocation`, `CompanyTelephone`, `CompanyMission`, `CompanyVision`, `CompanyAbout`, `CompanyVacancy`) VALUES
(1, '1', '1', '1', '1', 1, '1', '1', '1', '1'),
(2, '1', '1', '1', '1', 1, '1', '1', '1', '1'),
(3, '1', '1', '1', '1', 1, '1', '1', '1', '1'),
(4, 'Safaricom', '1', '43', '1', 1, '1', '1', '1', '1'),
(5, '1', '1', 'Nairobi', '1', 1, '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `ProjectId` int(11) NOT NULL,
  `ProjectTitle` varchar(5000) CHARACTER SET utf8 DEFAULT NULL,
  `ProjectDescription` varchar(9000) DEFAULT NULL,
  `TeamMemberId` int(11) DEFAULT NULL,
  `TeamId` int(11) DEFAULT NULL,
  `CompanyId` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`ProjectId`, `ProjectTitle`, `ProjectDescription`, `TeamMemberId`, `TeamId`, `CompanyId`) VALUES
(7, 'UHC', 'from MoH', NULL, NULL, NULL),
(8, 'uhc', 'networks', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `project_objectives`
--

CREATE TABLE `project_objectives` (
  `ProjectObjectiveId` int(11) NOT NULL,
  `ProjectId` int(11) NOT NULL,
  `TeamMemberId` int(11) NOT NULL,
  `ProjectObjective` varchar(9000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `system_admin`
--

CREATE TABLE `system_admin` (
  `AdminId` int(11) NOT NULL,
  `AdminFirstName` varchar(200) NOT NULL,
  `AdminMiddleName` varchar(200) NOT NULL,
  `AdminSurname` varchar(200) NOT NULL,
  `AdminPhoneNumber` varchar(200) NOT NULL,
  `AdminEmail` varchar(200) NOT NULL,
  `GenderId` int(200) NOT NULL,
  `AdminNationalId` int(11) NOT NULL,
  `EncryptedPassword` varchar(5000) NOT NULL,
  `Salt` varchar(5000) NOT NULL,
  `RegisteredDate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `system_admin`
--

INSERT INTO `system_admin` (`AdminId`, `AdminFirstName`, `AdminMiddleName`, `AdminSurname`, `AdminPhoneNumber`, `AdminEmail`, `GenderId`, `AdminNationalId`, `EncryptedPassword`, `Salt`, `RegisteredDate`) VALUES
(1, 'Mary', 'Konyango', 'Adhiambo', '0727767166', 'mary@gmail.com', 1, 31547207, '8ac4b72170b4c637cd93f36457bc31a0f8e73093972bbd6ca7366c5dec3a2bd88aa97dbe72e95c5813f32df0cb1608eb7444d88d047143e1c2941d37da851df2', 'ODjXUGXFO/0+v5d/e45iRSjts/5ZZaJtziUgvBzVAl36F5x+Bm7qmZAP6fNMFLVo5YyVxfruBn7RMsz4MPbK3ghkk/FGjkfWB8soelmhaHaEs456u6iHCYx+I5npgf1u4Cx0/c1wEjHC6COstL1RH8oqqgMXKvSpFvXuFjvBXeE=', '2020-04-15 20:38:10');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE `team` (
  `TeamId` int(11) NOT NULL,
  `TeamName` varchar(200) NOT NULL,
  `CompanyId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `TeamMemberId` int(11) NOT NULL,
  `TeamMemberName` varchar(200) NOT NULL,
  `TeamMemberEmail` varchar(200) NOT NULL,
  `TeamId` int(11) NOT NULL,
  `CompanyId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`CompanyId`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`ProjectId`),
  ADD KEY `TeamId` (`TeamId`),
  ADD KEY `TeamMemberId` (`TeamMemberId`),
  ADD KEY `CompanyId` (`CompanyId`);

--
-- Indexes for table `project_objectives`
--
ALTER TABLE `project_objectives`
  ADD PRIMARY KEY (`ProjectObjectiveId`),
  ADD KEY `TeamMemberId` (`TeamMemberId`),
  ADD KEY `ProjectId` (`ProjectId`);

--
-- Indexes for table `system_admin`
--
ALTER TABLE `system_admin`
  ADD PRIMARY KEY (`AdminId`);

--
-- Indexes for table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`TeamId`),
  ADD KEY `CompanyId` (`CompanyId`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`TeamMemberId`),
  ADD KEY `TeamId` (`TeamId`),
  ADD KEY `CompanyId` (`CompanyId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `CompanyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `ProjectId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `project_objectives`
--
ALTER TABLE `project_objectives`
  MODIFY `ProjectObjectiveId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `system_admin`
--
ALTER TABLE `system_admin`
  MODIFY `AdminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `team`
--
ALTER TABLE `team`
  MODIFY `TeamId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `team_members`
--
ALTER TABLE `team_members`
  MODIFY `TeamMemberId` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`TeamId`) REFERENCES `team` (`TeamId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `projects_ibfk_2` FOREIGN KEY (`TeamMemberId`) REFERENCES `team_members` (`TeamMemberId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `projects_ibfk_3` FOREIGN KEY (`CompanyId`) REFERENCES `company` (`CompanyId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_objectives`
--
ALTER TABLE `project_objectives`
  ADD CONSTRAINT `project_objectives_ibfk_1` FOREIGN KEY (`TeamMemberId`) REFERENCES `team_members` (`TeamMemberId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `project_objectives_ibfk_2` FOREIGN KEY (`ProjectId`) REFERENCES `projects` (`ProjectId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `team`
--
ALTER TABLE `team`
  ADD CONSTRAINT `team_ibfk_1` FOREIGN KEY (`CompanyId`) REFERENCES `company` (`CompanyId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `team_members`
--
ALTER TABLE `team_members`
  ADD CONSTRAINT `team_members_ibfk_1` FOREIGN KEY (`TeamId`) REFERENCES `team` (`TeamId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `team_members_ibfk_2` FOREIGN KEY (`CompanyId`) REFERENCES `company` (`CompanyId`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
