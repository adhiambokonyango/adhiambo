-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 23, 2020 at 09:31 AM
-- Server version: 5.7.29
-- PHP Version: 7.1.33-14+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid`
--

-- --------------------------------------------------------

--
-- Table structure for table `children_tips`
--

CREATE TABLE `children_tips` (
  `ChildrenTipsId` int(11) NOT NULL,
  `ChildrenTipsTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `children_tips`
--

INSERT INTO `children_tips` (`ChildrenTipsId`, `ChildrenTipsTitle`) VALUES
(1, 'advice'),
(2, 'talk to children'),
(3, 'talk to children'),
(4, 'talk to children'),
(5, 'talk to children about virus'),
(6, 'keep indoors');

-- --------------------------------------------------------

--
-- Table structure for table `children_tips_description`
--

CREATE TABLE `children_tips_description` (
  `ChildrenTipsDescriptionId` int(11) NOT NULL,
  `ChildrenTipsId` int(11) NOT NULL,
  `ChildrenTipsDescription` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `children_tips_description`
--

INSERT INTO `children_tips_description` (`ChildrenTipsDescriptionId`, `ChildrenTipsId`, `ChildrenTipsDescription`) VALUES
(1, 2, 'advice them'),
(2, 5, 'give them details'),
(3, 1, 'advice them'),
(4, 1, 'give them details'),
(5, 3, 'advice them'),
(6, 3, 'give them details'),
(7, 6, 'to avoid contact');

-- --------------------------------------------------------

--
-- Table structure for table `county`
--

CREATE TABLE `county` (
  `CountyId` int(11) NOT NULL,
  `CountyTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `county`
--

INSERT INTO `county` (`CountyId`, `CountyTitle`) VALUES
(1, 'Nairobi');

-- --------------------------------------------------------

--
-- Table structure for table `county_death`
--

CREATE TABLE `county_death` (
  `CountyId` int(11) NOT NULL,
  `CountyDeathId` int(11) NOT NULL,
  `CountyDeath` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `county_infected`
--

CREATE TABLE `county_infected` (
  `CountyId` int(11) NOT NULL,
  `CountyInfectedId` int(11) NOT NULL,
  `CountyInfectedNumbers` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `measure`
--

CREATE TABLE `measure` (
  `MeasureId` int(11) NOT NULL,
  `MeasureTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `measure`
--

INSERT INTO `measure` (`MeasureId`, `MeasureTitle`) VALUES
(1, 'wash hands'),
(2, 'wash hands frequently'),
(3, 'wash hands frequently');

-- --------------------------------------------------------

--
-- Table structure for table `measure_description`
--

CREATE TABLE `measure_description` (
  `MeasureDescriptionId` int(11) NOT NULL,
  `MeasureId` int(11) NOT NULL,
  `MeasureDescription` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `measure_description`
--

INSERT INTO `measure_description` (`MeasureDescriptionId`, `MeasureId`, `MeasureDescription`) VALUES
(1, 1, 'use alcohal based');

-- --------------------------------------------------------

--
-- Table structure for table `myths`
--

CREATE TABLE `myths` (
  `MythsId` int(11) NOT NULL,
  `MythsTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `myths`
--

INSERT INTO `myths` (`MythsId`, `MythsTitle`) VALUES
(1, 'transfered by dogs');

-- --------------------------------------------------------

--
-- Table structure for table `myths_description`
--

CREATE TABLE `myths_description` (
  `MythsDescriptionId` int(11) NOT NULL,
  `MythsId` int(11) NOT NULL,
  `MythsDescription` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `myths_description`
--

INSERT INTO `myths_description` (`MythsDescriptionId`, `MythsId`, `MythsDescription`) VALUES
(1, 1, 'not possible'),
(2, 1, 'not possible to happen'),
(3, 1, 'not possible to happen');

-- --------------------------------------------------------

--
-- Table structure for table `preventions`
--

CREATE TABLE `preventions` (
  `PreventionId` int(11) NOT NULL,
  `PreventionTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `preventions`
--

INSERT INTO `preventions` (`PreventionId`, `PreventionTitle`) VALUES
(1, 'stay at home');

-- --------------------------------------------------------

--
-- Table structure for table `prevention_descriptions`
--

CREATE TABLE `prevention_descriptions` (
  `PreventioDescriptionId` int(11) NOT NULL,
  `PreventionId` int(11) NOT NULL,
  `PreventionDescription` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `prevention_descriptions`
--

INSERT INTO `prevention_descriptions` (`PreventioDescriptionId`, `PreventionId`, `PreventionDescription`) VALUES
(1, 1, 'all the time');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `QuestionId` int(11) NOT NULL,
  `QuestionTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`QuestionId`, `QuestionTitle`) VALUES
(1, 'what do i do ');

-- --------------------------------------------------------

--
-- Table structure for table `question_description`
--

CREATE TABLE `question_description` (
  `QuestionDescriptionId` int(11) NOT NULL,
  `QuestionId` int(11) NOT NULL,
  `QuestionDescription` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question_description`
--

INSERT INTO `question_description` (`QuestionDescriptionId`, `QuestionId`, `QuestionDescription`) VALUES
(1, 1, 'report');

-- --------------------------------------------------------

--
-- Table structure for table `scams`
--

CREATE TABLE `scams` (
  `ScamId` int(11) NOT NULL,
  `ScamTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `scams`
--

INSERT INTO `scams` (`ScamId`, `ScamTitle`) VALUES
(1, 'cone');

-- --------------------------------------------------------

--
-- Table structure for table `scam_description`
--

CREATE TABLE `scam_description` (
  `ScamDescriptionId` int(11) NOT NULL,
  `ScamId` int(11) NOT NULL,
  `ScamDescription` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stress_coping`
--

CREATE TABLE `stress_coping` (
  `StressCopingId` int(11) NOT NULL,
  `StressCopingTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stress_coping`
--

INSERT INTO `stress_coping` (`StressCopingId`, `StressCopingTitle`) VALUES
(1, 'keep calm');

-- --------------------------------------------------------

--
-- Table structure for table `stress_coping_description`
--

CREATE TABLE `stress_coping_description` (
  `StressCopingDescriptionId` int(11) NOT NULL,
  `StressCopingId` int(11) NOT NULL,
  `StressCopingDescription` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

CREATE TABLE `symptoms` (
  `SymptomId` int(11) NOT NULL,
  `SymptomTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `symptoms`
--

INSERT INTO `symptoms` (`SymptomId`, `SymptomTitle`) VALUES
(1, 'cough'),
(2, 'cough');

-- --------------------------------------------------------

--
-- Table structure for table `symptom_descriptions`
--

CREATE TABLE `symptom_descriptions` (
  `SymptomDescriptionId` int(11) NOT NULL,
  `SymptomId` int(11) NOT NULL,
  `SymptomDescription` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `testing`
--

CREATE TABLE `testing` (
  `TestingId` int(11) NOT NULL,
  `TestingTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testing`
--

INSERT INTO `testing` (`TestingId`, `TestingTitle`) VALUES
(1, 'done at knh');

-- --------------------------------------------------------

--
-- Table structure for table `testing_description`
--

CREATE TABLE `testing_description` (
  `TestingDescriptionId` int(11) NOT NULL,
  `TestingId` int(11) NOT NULL,
  `TestingDescription` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `travel`
--

CREATE TABLE `travel` (
  `TravelId` int(11) NOT NULL,
  `TravelTitle` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `travel_description`
--

CREATE TABLE `travel_description` (
  `TravelDescriptionId` int(11) NOT NULL,
  `TravelId` int(11) NOT NULL,
  `TravelDescription` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `treatment`
--

CREATE TABLE `treatment` (
  `TreatmentId` int(11) NOT NULL,
  `TreatmentTitle` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `treatment`
--

INSERT INTO `treatment` (`TreatmentId`, `TreatmentTitle`) VALUES
(1, 'symptom treatment');

-- --------------------------------------------------------

--
-- Table structure for table `treatment_description`
--

CREATE TABLE `treatment_description` (
  `TreatmentDescriptionId` int(11) NOT NULL,
  `TreatmentId` int(11) NOT NULL,
  `TreatmentDescription` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `children_tips`
--
ALTER TABLE `children_tips`
  ADD PRIMARY KEY (`ChildrenTipsId`);

--
-- Indexes for table `children_tips_description`
--
ALTER TABLE `children_tips_description`
  ADD PRIMARY KEY (`ChildrenTipsDescriptionId`),
  ADD KEY `ChildrenTipsId` (`ChildrenTipsId`);

--
-- Indexes for table `county`
--
ALTER TABLE `county`
  ADD PRIMARY KEY (`CountyId`);

--
-- Indexes for table `county_death`
--
ALTER TABLE `county_death`
  ADD PRIMARY KEY (`CountyDeathId`),
  ADD KEY `CountyId` (`CountyId`);

--
-- Indexes for table `county_infected`
--
ALTER TABLE `county_infected`
  ADD PRIMARY KEY (`CountyInfectedId`),
  ADD KEY `CountyId` (`CountyId`);

--
-- Indexes for table `measure`
--
ALTER TABLE `measure`
  ADD PRIMARY KEY (`MeasureId`);

--
-- Indexes for table `measure_description`
--
ALTER TABLE `measure_description`
  ADD PRIMARY KEY (`MeasureDescriptionId`),
  ADD KEY `MeasureId` (`MeasureId`);

--
-- Indexes for table `myths`
--
ALTER TABLE `myths`
  ADD PRIMARY KEY (`MythsId`);

--
-- Indexes for table `myths_description`
--
ALTER TABLE `myths_description`
  ADD PRIMARY KEY (`MythsDescriptionId`),
  ADD KEY `MythsId` (`MythsId`);

--
-- Indexes for table `preventions`
--
ALTER TABLE `preventions`
  ADD PRIMARY KEY (`PreventionId`);

--
-- Indexes for table `prevention_descriptions`
--
ALTER TABLE `prevention_descriptions`
  ADD PRIMARY KEY (`PreventioDescriptionId`),
  ADD KEY `PreventionId` (`PreventionId`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`QuestionId`);

--
-- Indexes for table `question_description`
--
ALTER TABLE `question_description`
  ADD PRIMARY KEY (`QuestionDescriptionId`),
  ADD KEY `QuestionId` (`QuestionId`);

--
-- Indexes for table `scams`
--
ALTER TABLE `scams`
  ADD PRIMARY KEY (`ScamId`);

--
-- Indexes for table `scam_description`
--
ALTER TABLE `scam_description`
  ADD PRIMARY KEY (`ScamDescriptionId`),
  ADD KEY `ScamId` (`ScamId`);

--
-- Indexes for table `stress_coping`
--
ALTER TABLE `stress_coping`
  ADD PRIMARY KEY (`StressCopingId`);

--
-- Indexes for table `stress_coping_description`
--
ALTER TABLE `stress_coping_description`
  ADD PRIMARY KEY (`StressCopingDescriptionId`),
  ADD KEY `StressCopingId` (`StressCopingId`);

--
-- Indexes for table `symptoms`
--
ALTER TABLE `symptoms`
  ADD PRIMARY KEY (`SymptomId`);

--
-- Indexes for table `symptom_descriptions`
--
ALTER TABLE `symptom_descriptions`
  ADD PRIMARY KEY (`SymptomDescriptionId`),
  ADD KEY `SymptomId` (`SymptomId`);

--
-- Indexes for table `testing`
--
ALTER TABLE `testing`
  ADD PRIMARY KEY (`TestingId`);

--
-- Indexes for table `testing_description`
--
ALTER TABLE `testing_description`
  ADD PRIMARY KEY (`TestingDescriptionId`),
  ADD KEY `TestingId` (`TestingId`);

--
-- Indexes for table `travel`
--
ALTER TABLE `travel`
  ADD PRIMARY KEY (`TravelId`);

--
-- Indexes for table `travel_description`
--
ALTER TABLE `travel_description`
  ADD PRIMARY KEY (`TravelDescriptionId`),
  ADD KEY `TravelId` (`TravelId`);

--
-- Indexes for table `treatment`
--
ALTER TABLE `treatment`
  ADD PRIMARY KEY (`TreatmentId`);

--
-- Indexes for table `treatment_description`
--
ALTER TABLE `treatment_description`
  ADD PRIMARY KEY (`TreatmentDescriptionId`),
  ADD KEY `TreatmentId` (`TreatmentId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `children_tips`
--
ALTER TABLE `children_tips`
  MODIFY `ChildrenTipsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `children_tips_description`
--
ALTER TABLE `children_tips_description`
  MODIFY `ChildrenTipsDescriptionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `county`
--
ALTER TABLE `county`
  MODIFY `CountyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `county_death`
--
ALTER TABLE `county_death`
  MODIFY `CountyDeathId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `county_infected`
--
ALTER TABLE `county_infected`
  MODIFY `CountyInfectedId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `measure`
--
ALTER TABLE `measure`
  MODIFY `MeasureId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `measure_description`
--
ALTER TABLE `measure_description`
  MODIFY `MeasureDescriptionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `myths`
--
ALTER TABLE `myths`
  MODIFY `MythsId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `myths_description`
--
ALTER TABLE `myths_description`
  MODIFY `MythsDescriptionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `preventions`
--
ALTER TABLE `preventions`
  MODIFY `PreventionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `prevention_descriptions`
--
ALTER TABLE `prevention_descriptions`
  MODIFY `PreventioDescriptionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `QuestionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `question_description`
--
ALTER TABLE `question_description`
  MODIFY `QuestionDescriptionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `scams`
--
ALTER TABLE `scams`
  MODIFY `ScamId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `scam_description`
--
ALTER TABLE `scam_description`
  MODIFY `ScamDescriptionId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stress_coping`
--
ALTER TABLE `stress_coping`
  MODIFY `StressCopingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `stress_coping_description`
--
ALTER TABLE `stress_coping_description`
  MODIFY `StressCopingDescriptionId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `symptoms`
--
ALTER TABLE `symptoms`
  MODIFY `SymptomId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `symptom_descriptions`
--
ALTER TABLE `symptom_descriptions`
  MODIFY `SymptomDescriptionId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `testing`
--
ALTER TABLE `testing`
  MODIFY `TestingId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `testing_description`
--
ALTER TABLE `testing_description`
  MODIFY `TestingDescriptionId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `travel`
--
ALTER TABLE `travel`
  MODIFY `TravelId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `travel_description`
--
ALTER TABLE `travel_description`
  MODIFY `TravelDescriptionId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `treatment`
--
ALTER TABLE `treatment`
  MODIFY `TreatmentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `treatment_description`
--
ALTER TABLE `treatment_description`
  MODIFY `TreatmentDescriptionId` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `children_tips_description`
--
ALTER TABLE `children_tips_description`
  ADD CONSTRAINT `children_tips_description_ibfk_1` FOREIGN KEY (`ChildrenTipsId`) REFERENCES `children_tips` (`ChildrenTipsId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `county_death`
--
ALTER TABLE `county_death`
  ADD CONSTRAINT `county_death_ibfk_1` FOREIGN KEY (`CountyId`) REFERENCES `county` (`CountyId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `county_infected`
--
ALTER TABLE `county_infected`
  ADD CONSTRAINT `county_infected_ibfk_1` FOREIGN KEY (`CountyId`) REFERENCES `county` (`CountyId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `measure_description`
--
ALTER TABLE `measure_description`
  ADD CONSTRAINT `measure_description_ibfk_1` FOREIGN KEY (`MeasureId`) REFERENCES `measure` (`MeasureId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `myths_description`
--
ALTER TABLE `myths_description`
  ADD CONSTRAINT `myths_description_ibfk_1` FOREIGN KEY (`MythsId`) REFERENCES `myths` (`MythsId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `prevention_descriptions`
--
ALTER TABLE `prevention_descriptions`
  ADD CONSTRAINT `prevention_descriptions_ibfk_1` FOREIGN KEY (`PreventionId`) REFERENCES `preventions` (`PreventionId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `question_description`
--
ALTER TABLE `question_description`
  ADD CONSTRAINT `question_description_ibfk_1` FOREIGN KEY (`QuestionId`) REFERENCES `questions` (`QuestionId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `scam_description`
--
ALTER TABLE `scam_description`
  ADD CONSTRAINT `scam_description_ibfk_1` FOREIGN KEY (`ScamId`) REFERENCES `scams` (`ScamId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `stress_coping_description`
--
ALTER TABLE `stress_coping_description`
  ADD CONSTRAINT `stress_coping_description_ibfk_1` FOREIGN KEY (`StressCopingId`) REFERENCES `stress_coping` (`StressCopingId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `symptom_descriptions`
--
ALTER TABLE `symptom_descriptions`
  ADD CONSTRAINT `symptom_descriptions_ibfk_1` FOREIGN KEY (`SymptomId`) REFERENCES `symptoms` (`SymptomId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `testing_description`
--
ALTER TABLE `testing_description`
  ADD CONSTRAINT `testing_description_ibfk_1` FOREIGN KEY (`TestingId`) REFERENCES `testing` (`TestingId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `travel_description`
--
ALTER TABLE `travel_description`
  ADD CONSTRAINT `travel_description_ibfk_1` FOREIGN KEY (`TravelId`) REFERENCES `travel` (`TravelId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `treatment_description`
--
ALTER TABLE `treatment_description`
  ADD CONSTRAINT `treatment_description_ibfk_1` FOREIGN KEY (`TreatmentId`) REFERENCES `treatment` (`TreatmentId`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
